
class QConfCommand(object):
    """Class wrapper for gathering and sending qconf commands"""
    def __init__(self):
        super(QConfCommand, self).__init__()
        