Lipsync core Python module
=======================

This project contins basic libraries for quering and manipulating folders, sequences and shotgun entities


